//
//  AKNewsViewController.h
//  Project
//
//  Created by ankye on 2016/12/20.
//  Copyright © 2016年 ankye. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AKNewsViewController : UIViewController

@end
