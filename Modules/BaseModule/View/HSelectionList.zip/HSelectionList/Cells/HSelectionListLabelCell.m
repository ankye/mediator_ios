//
//  HSelectionListLabelCell.m
//  HSelectionList Example
//
//  Created by Erik Ackermann on 2/26/15.
//  Copyright (c) 2015 Hightower. All rights reserved.
//

#import "HSelectionListLabelCell.h"

#import <M13BadgeView/M13BadgeView.h>

@interface HSelectionListLabelCell ()

@property (nonatomic, strong) UILabel *titleLabel;

@property (nonatomic, strong) M13BadgeView *badgeView;

@property (nonatomic, strong) NSMutableDictionary *titleColorsByState;
@property (nonatomic, strong) NSMutableDictionary *titleFontsByState;

//@property (nonatomic) UIControlState state;
//@property (nonatomic, strong) NSString *badgeValue;

@property (nonatomic, strong) NSMutableDictionary* info;


@end

@implementation HSelectionListLabelCell


- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;

        [self.contentView addSubview:_titleLabel];

        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[_titleLabel]|"
                                                                                 options:NSLayoutFormatDirectionLeadingToTrailing
                                                                                 metrics:nil
                                                                                   views:NSDictionaryOfVariableBindings(_titleLabel)]];

        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[_titleLabel]|"
                                                                                 options:NSLayoutFormatDirectionLeadingToTrailing
                                                                                 metrics:nil
                                                                                   views:NSDictionaryOfVariableBindings(_titleLabel)]];

        _badgeView = [[M13BadgeView alloc] initWithFrame:CGRectMake(0, 0, 8, 14)];
        _badgeView.font = [UIFont systemFontOfSize:10];
        _badgeView.horizontalAlignment = M13BadgeViewHorizontalAlignmentRight;
        _badgeView.alignmentShift = CGSizeMake(-5, (self.frame.size.height - _badgeView.frame.size.height) * 0.5);
        _badgeView.hidesWhenZero = YES;
        [_titleLabel addSubview:_badgeView];

        _titleColorsByState = [NSMutableDictionary dictionary];
        _titleColorsByState[@(UIControlStateNormal)] = [UIColor blackColor];

        _titleFontsByState = [NSMutableDictionary dictionary];
        _titleFontsByState[@(UIControlStateNormal)] = [UIFont systemFontOfSize:13];

      //  _state = UIControlStateNormal;
    }
    return self;
}

- (void)prepareForReuse {
    [super prepareForReuse];

    NSLog(@"回收 %@",self.title);
    
    self.title = nil;
    self.titleColorsByState = [NSMutableDictionary dictionary];
    self.titleColorsByState[@(UIControlStateNormal)] = [UIColor blackColor];
    self.titleFontsByState = [NSMutableDictionary dictionary];
    self.titleFontsByState[@(UIControlStateNormal)] = [UIFont systemFontOfSize:13];
    [self setState:UIControlStateNormal];
    self.titleLabel.textColor = self.titleColorsByState[@(UIControlStateNormal)];
    
    self.info = nil;
    
  //  self.state = UIControlStateNormal;
}

- (void)layoutSubviews {
    [super layoutSubviews];

    [self.contentView layoutSubviews];
    [self.titleLabel layoutSubviews];

    self.badgeView.text = self.info[@"badge"] ? self.info[@"badge"] : @"0";
}

#pragma mark - Public Methods

+ (CGSize)sizeForTitle:(NSString *)title withFont:(UIFont *)font {
    CGRect titleRect = [title boundingRectWithSize:CGSizeMake(FLT_MAX, FLT_MAX)
                                           options:NSStringDrawingUsesLineFragmentOrigin
                                        attributes:@{NSFontAttributeName : font}
                                           context:nil];

    return CGSizeMake(titleRect.size.width,
                      titleRect.size.height);
}

#pragma mark - Custom Getters and Setters

- (void)setTitle:(NSString *)title {
    _title = title;
    if(title){
        NSLog(@"set title %@",title);
    }
    self.titleLabel.text = title;
}

- (void)setBadgeValue:(NSString *)badgeValue {
   // _badgeValue = badgeValue;

    [self setNeedsLayout];
}

- (void)setState:(UIControlState)state {
 //   _state = state;

    [self updateTitleColor];
    [self updateTitleFont];
}

- (void)setTitleColor:(UIColor *)color forState:(UIControlState)state {
    self.titleColorsByState[@(state)] = color;

    [self updateTitleColor];
}

- (void)setTitleFont:(UIFont *)font forState:(UIControlState)state {
    self.titleFontsByState[@(state)] = font;

    [self updateTitleFont];
}

-(void)setCellInfo:(NSMutableDictionary*)info
{
    self.info = info;
    [self setBadgeValue:info[@"badge"]];
    [self setState:[info[@"state"] integerValue]];
}

#pragma mark - Private Methods

- (void)updateTitleColor {
    UIControlState state = [self.info[@"state"] integerValue];
    self.titleLabel.textColor = self.titleColorsByState[@(state)] ?: self.titleColorsByState[@(UIControlStateNormal)];
}

- (void)updateTitleFont {
    UIControlState state = [self.info[@"state"] integerValue];
    self.titleLabel.font = self.titleFontsByState[@(state)] ?: self.titleFontsByState[@(UIControlStateNormal)];
}

@end
